# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import ir_model
import ir_sequence
import ir_needaction
import ir_ui_menu
import ir_ui_view
import ir_actions
import ir_attachment
import ir_cron
import ir_filters
import ir_values
import ir_translation
import ir_exports
import ir_rule
import ir_config_parameter
import ir_autovacuum
import ir_mail_server
import ir_fields
import ir_qweb
import ir_http
import ir_logging
