# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import ir_attachment
import ir_qweb
import ir_ui_view
import ir_http
import ir_translation

import test_models
