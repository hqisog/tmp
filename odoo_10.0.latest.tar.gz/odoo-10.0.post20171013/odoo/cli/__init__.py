import logging
import sys
import os

import odoo

from command import Command, main

import deploy
import scaffold
import server
import shell
import start
